//: [Previous](@previous)

import UIKit
import SwiftUI
import PlaygroundSupport
import SpriteKit
import Security
import Darwin
import AVFoundation

struct MonkeyView: View {
    @State var scale = 0.15
    @State var disappearedMonkey = 0.0001
    @State var monkeyScale = 0.90
    @State var monkeyOpacity : Double = 0
    @State var textOpacity : Double = 0
    @State var titleOpacity : Double = 1
    @State var monkeyY : CGFloat = 300
    @State var jump : Bool = false
    @State var count : CGFloat = 0
    @State var cageScale = 0.30
    @State var cageX : CGFloat = 305
    @State var cageY : CGFloat = -200
    @State var cacciatoreX : CGFloat = -200
    @State var cacciatoreY : CGFloat = 233
    @State var tap : Bool = false
    @State var alreadyTap: Bool = false
    @State var scena : Bool = true
    @State var laugh: AVAudioPlayer?
    @State var cage: AVAudioPlayer?
    @State var theme: AVAudioPlayer?
    @State var comic: AVAudioPlayer?
    
    var body: some View {
            ZStack {
                if (!alreadyTap) {
                    Image(uiImage: UIImage(named: "background.jpg")!)
                        .resizable()
                        .frame(width: 600, height: 400, alignment: .topLeading)
                        .aspectRatio(contentMode: .fill)
                        .onAppear{
                            startTheme()
                        }
                    
                    Text("A Story about a Monkey")
                        .font(.largeTitle.weight(.thin))
                        .frame(width: 550)
                        .foregroundColor(.white)
                        .background(Color.yellow)
                        .cornerRadius(10)
                        .position(x: 300, y: 200)
                        .opacity(titleOpacity)
                        .animation(.linear(duration: 0.4), value: titleOpacity)
                    
                    Image(uiImage: UIImage(named: "monkeys.png")!)
                        .padding()
                        .scaledToFit()
                        .opacity(monkeyOpacity)
                        .scaleEffect(monkeyScale)
                        .position(x: 300 , y: monkeyY)
                        .onTapGesture {
                            if (!jump) {
                                monkeyY -= 20
                                jump = true
                                startLaugh()
                            } else if (jump) {
                                monkeyY += 20
                                jump = false
                                startLaugh()

                            }
                        }
                        .animation(.linear(duration: 0.5).repeatCount(2, autoreverses: true), value: monkeyY)
                        .animation(.linear(duration: 0.3), value: monkeyOpacity)
                    
                    Image(uiImage: UIImage(named: "cage.png")!)
                        .padding()
                        .scaledToFit()
                        .scaleEffect(cageScale)
                        .animation(
                            .easeOut(duration: 3),
                            value: cageX)
                        .animation(
                            .easeOut(duration: 3),
                            value: cageY)
                        .position(x: cageX, y: cageY)
                    
                    Button {
                        if (!tap) {
                            if (monkeyOpacity == 0){
                                monkeyOpacity = 1
                                textOpacity = 1
                                titleOpacity = 0
                            }else {
                                tap = true
                                monkeyY = 280
                                cageX = 300
                                cageY = 240
                                cacciatoreX = 150
                                cacciatoreY = 233
                                DispatchQueue.main.asyncAfter(deadline: .now() + 0.9, execute: {
                                    startCage()
                                })
                            }
                        } else if (tap == true && alreadyTap == false) {
                            alreadyTap = true
                            tap = false
                            theme?.stop()
                            cage?.stop()
                        }
                    } label: {
                        Image(uiImage: UIImage(named: "next.png")!).resizable().frame(width: 50, height: 50)
                    }
                    .position(x: 550, y: 300)
                    
                    Image(uiImage: UIImage(named: "cacciatore.png")!)
                        .padding()
                        .scaledToFit()
                        .scaleEffect()
                        .animation(
                            .easeOut(duration: 3),
                            value: cacciatoreX)
                        .animation(
                            .easeOut(duration: 3),
                            value: cacciatoreY)
                        .position(x: cacciatoreX, y: cacciatoreY)
                    
                    if (!tap) {
                        Text("Once upon a time there was a monkey called Gibbons who lived in a big jungle.")
                            .font(.system(size: 19, weight: .light, design: .serif))
                            .frame(width: 500)
                            .foregroundColor(.blue)
                            .background(Color.yellow)
                            .cornerRadius(10)
                            .position(x: 300, y: 370)
                            .opacity(textOpacity)
                            .animation(.linear(duration: 0.5), value: textOpacity)
                    }
                    
                    if (tap) {
                        Text("One day poachers kidnapped and put it in a cage and sent Gibbons to a big city.")
                            .font(.system(size: 19, weight: .light, design: .serif))
                            .frame(width: 500)
                            .foregroundColor(.blue)
                            .background(Color.yellow)
                            .cornerRadius(10)
                            .position(x: 300, y: 370)
                    }
                    
                }
                
                if (alreadyTap) {
                    Image(uiImage: UIImage(named: "open door.jpg")!)
                        .resizable()
                        .frame(width: 600, height: 400, alignment: .topLeading)
                        .aspectRatio(contentMode: .fill)
                    
                    Image(uiImage: UIImage(named: "exit-sign.png")!)
                        .padding()
                        .scaledToFit()
                        .scaleEffect(scale)
                        .position(x: 297 , y: 60)
                        .onAppear {
                            scale = 0.25
                        }
                        .animation(.linear(duration: 1.5).repeatForever(autoreverses: true), value: scale)
                    
                    Image(uiImage: UIImage(named: "monkeys.png")!)
                        .padding()
                        .scaledToFit()
                        .scaleEffect(disappearedMonkey)
                        .position(x: 300 , y: 250)
                        .animation(.linear(duration: 1), value: disappearedMonkey)
                    
                    Button {
                        disappearedMonkey = monkeyScale
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.9, execute: {
                            startComic()
                        })
                    } label: {
                        Image(uiImage: UIImage(named: "next.png")!).resizable().frame(width: 50, height: 50)
                    }
                    .position(x: 550, y: 300)
                    
                    Text("Those idiots, however, forgot to lock it with a padlock and Gibbons managed to escape.")
                        .font(.system(size: 19, weight: .light, design: .serif))
                        .frame(width: 500)
                        .foregroundColor(.blue)
                        .background(Color.yellow)
                        .cornerRadius(10)
                        .position(x: 300, y: 370)
                }
            }
            .frame(width: 600, height: 400)
            
        }
    
    func startLaugh() {
        if let audioURL = Bundle.main.url(forResource: "laugh", withExtension: "mp3") {
            do {
                try laugh = AVAudioPlayer(contentsOf: audioURL)
                laugh?.numberOfLoops = 0
                laugh?.volume = 2
                laugh?.play()
                
                
            } catch {
                print("Couldn't play audio. Error: \(error)")
            }
            
        } else {
            print("No audio file found")
        }
    }
    
    func startCage() {
        if let audioURL = Bundle.main.url(forResource: "cage", withExtension: "mp3") {
            do {
                try cage = AVAudioPlayer(contentsOf: audioURL)
                cage?.numberOfLoops = 0
                cage?.volume = 4
                cage?.play()
                
                
            } catch {
                print("Couldn't play audio. Error: \(error)")
            }
            
        } else {
            print("No audio file found")
        }
    }
    
    func startTheme() {
        if let audioURL = Bundle.main.url(forResource: "theme", withExtension: "mp3") {
            do {
                try theme = AVAudioPlayer(contentsOf: audioURL)
                theme?.numberOfLoops = 40
                theme?.volume = 0.5
                theme?.play()
                
                
            } catch {
                print("Couldn't play audio. Error: \(error)")
            }
            
        } else {
            print("No audio file found")
        }
    }
    
    func startComic() {
        if let audioURL = Bundle.main.url(forResource: "comic", withExtension: "mp3") {
            do {
                try comic = AVAudioPlayer(contentsOf: audioURL)
                comic?.numberOfLoops = 0
                comic?.volume = 5
                comic?.play()
                
            } catch {
                print("Couldn't play audio. Error: \(error)")
            }
            
        } else {
            print("No audio file found")
        }
    }
}

PlaygroundPage.current.setLiveView(MonkeyView())

//: [Next](@next)

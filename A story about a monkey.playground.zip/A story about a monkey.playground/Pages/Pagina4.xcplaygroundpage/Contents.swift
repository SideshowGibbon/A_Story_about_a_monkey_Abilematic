//: [Previous](@previous)

import SwiftUI
import AVFoundation
import PlaygroundSupport

struct ContentView: View {
    @State var scale = 0.75
    @State var rotation = false
    @State var scene1=true
    @State var manoX : CGFloat = 300
    @State var manoY : CGFloat = 500
    @State var manovisible=true
    @State var scena = false
    @State var next1 = false
    @State var theend = false
    @State var monkscale = 0.30
    @State var monkX : CGFloat = 290
    @State var monkY : CGFloat = 200
    @State var exit = true
    @State var scale1 = 0.15
    @State var scalecab = 0.0001
    @State var scalecab1 = 0.30
    @State var cabX : CGFloat = 290
    @State var cabY : CGFloat = 120
    @State var SPLAT: AVAudioPlayer?
    @State var bot: AVAudioPlayer?
    @State var ending: AVAudioPlayer?
    @State var walking: AVAudioPlayer?
    

    var body: some View {
        if(!theend && !scena && scene1){
                VStack {
                    Button {
                        if(!next1){
                            scale = 2
                            next1=true
                            startSPLAT()
                        }
                        else if(next1){
                            scene1=false
                        }
                                } label: {
                                    Image(uiImage: UIImage(named: "next.png")!).resizable().frame(width: 50, height: 50)
                                }
                                .offset(x: 250,y: 300)
                                HStack {
                                    Image(uiImage: UIImage(named: "splat.001.png")!)
                                        
                                        .resizable()
                                        .scaledToFit()
                                        .frame(width: 200, height: 200)
                                        .padding()
                                        .scaleEffect(scale)
                                        .animation(
                                            .easeOut(duration: 1.2),
                                            value: scale
                                        )
                                        .offset(y: -15)
                                        .offset(x: 5)
                                    
                }
                    Text("'DAMN' he exclaimed, the telephone booth had crushed a man who greeted the crowd with a high arm.")
                        .font(.system(size: 15, weight: .light, design: .serif))
                        .frame(width: 400)
                        .foregroundColor(.blue)
                        .background(Color.yellow)
                        .cornerRadius(10)
                        .offset(y: 30)
                }
//                .environment(\.colorScheme, .dark)
                .frame(width: 600, height: 400).background(Image(uiImage: UIImage(named: "sfondo.jpg")!).resizable().aspectRatio(contentMode: .fill))
        }
        
        if(!theend && !scena && !scene1){
            VStack{
                           
                           HStack{
                               Button {
                                   if(manovisible){
                                       manoX = 300
                                       manoY = 290
                                       manovisible=false
                                       startbot()
                                   }
                                   
                                   else if(!manovisible){
                                          scena=true
                                   }
                                } label: {
                                    Image(uiImage: UIImage(named: "next.png")!).resizable().frame(width: 50, height: 50)
                                        }
                                .offset(x: 270, y: 340)
                           }
                           Image(uiImage: UIImage(named: "MANO2.png")!)
                               .padding()
                               .scaledToFit()
                               .scaleEffect(0.55)
                               .transition(.move(edge: .top))
                               .animation(
                                .linear(duration: 1),
                                   value: manoX)
                               .animation(
                                .linear(duration: 0.2),
                                   value: manoY)
                               .position(x: manoX, y: manoY)
                                           
                Text("Gibbons then decided to reset the green button and found himself in the cabin at the starting point")
                                                   .font(.system(size: 17, weight: .light, design: .serif))
                                                   .frame(width: 520)
                                                   .foregroundColor(.blue)
                                                   .background(Color.yellow)
                                                   .cornerRadius(10)
                                                   .offset(x: -30 ,y: -8)
                       }
                       .frame(width: 600, height: 400)
                           .background(Image(uiImage: UIImage(named: "scene4.jpg")!).resizable().aspectRatio(contentMode: .fill))
        }
        if(!theend && scena && !scene1){
            VStack{
                if(exit){
                    Text("  Gibbons returned around the big town  ").foregroundColor(.blue)
                        .background(Color.yellow)
                        .cornerRadius(10)
                        .padding(30)
                        .multilineTextAlignment(.center)
                        
                }
                if(!exit){
                    Text("Gibbons doesn’t know but that World War II had never broken out and that Hitler had been assassinated by a monkey flying a telephone booth.")
                        .foregroundColor(.blue)
                        .background(Color.yellow)
                        .cornerRadius(10)
                        .padding(19.1)
                        .multilineTextAlignment(.center)
                }
               
                ZStack{
                    Button {
                        if(exit){
                            monkY -= 80
                            scale1=0.05
                            scalecab = 2
                            scalecab1=0.0001
                            cabX += 250
                            cabY += 30
                            exit=false
                            startWalking()
                        }
                        else if(!exit){
                            theend=true
                        }
                    }
                                 label: {
                                    Image(uiImage: UIImage(named: "next.png")!).resizable().frame(width: 50, height: 50)
                                }.offset(x: 250, y: 120)
        
                            
                    Image(uiImage: UIImage(named: "cabintime2.png")!)
                        .padding()
                        .scaledToFit()
                        .scaleEffect(scalecab1)
                        .animation(.linear(duration: 4),
                                   value:scalecab1
                        )
                        .transition(.move(edge: .top))
                        .animation(
                            .linear(duration: 2),
                            value: cabX)
                        .animation(
                            .linear(duration: 2),
                            value: cabY)
                        .position(x: cabX, y: cabY)
                    
                    Image(uiImage: #imageLiteral(resourceName: "Monkey_1.001.png"))
                                                .padding()
                                                .scaledToFit()
                                                .scaleEffect(scale1)
                                                .animation(.linear(duration: 4),
                                                           value:scale1
                                                )
                                                .transition(.move(edge: .top))
                                                .animation(
                                                    .linear(duration: 2),
                                                    value: monkX)
                                                .animation(
                                                    .linear(duration: 2),
                                                    value: monkY)
                                                .position(x: monkX, y: monkY)
                    
                    
                    Image(uiImage: #imageLiteral(resourceName: "cabina.png"))
                        .resizable()
                        .scaledToFit()
                        .frame(width: 75, height: 75)
                        .padding()
                        .scaleEffect(scalecab)
                        .animation(
                            .linear(duration: 4),
                            value: scalecab
                            )
                        .offset(x: 220, y: -20)
                    
                }
            }.frame(width: 600, height: 400).background(Image(uiImage: UIImage(named: "city.jpeg")!).resizable().aspectRatio(contentMode: .fill))
        }
        if(theend && scena && !scene1){
            VStack{
                
            }.frame(width: 600, height: 400).background(Image(uiImage: UIImage(named: "theend.jpeg")!).resizable().aspectRatio(contentMode: .fill))
                .onAppear{
                    startEnding()
                }
 
        }
        
        
}
    func startSPLAT() {
               if let audioURL = Bundle.main.url(forResource: "SPLAT", withExtension: "mp3") {
                   do {
                       try SPLAT = AVAudioPlayer(contentsOf: audioURL)
                       SPLAT?.numberOfLoops = 0
                       SPLAT?.play()
                       
                   } catch {
                       print("Couldn't play audio. Error: \(error)")
                   }
                   
               } else {
                   print("No audio file found")
               }
           }
        func startbot() {
               if let audioURL = Bundle.main.url(forResource: "bot", withExtension: "mp3") {
                   do {
                       try bot = AVAudioPlayer(contentsOf: audioURL)
                       bot?.numberOfLoops = 0
                       bot?.prepareToPlay()
                       bot?.play()
                       
                   } catch {
                       print("Couldn't play audio. Error: \(error)")
                   }
                   
               } else {
                   print("No audio file found")
               }
           }
    func startEnding() {
        if let audioURL = Bundle.main.url(forResource: "applause", withExtension: "wav") {
            do {
                try ending = AVAudioPlayer(contentsOf: audioURL)
                ending?.numberOfLoops = 0
                ending?.prepareToPlay()
                ending?.play()
                
            } catch {
                print("Couldn't play audio. Error: \(error)")
            }
            
        } else {
            print("No audio file found")
        }
    }
    
    func startWalking() {
        if let audioURL = Bundle.main.url(forResource: "walking", withExtension: "mp3") {
            do {
                try walking = AVAudioPlayer(contentsOf: audioURL)
                walking?.numberOfLoops = 1
                walking?.play()
                
            } catch {
                print("Couldn't play audio. Error: \(error)")
            }
            
        } else {
            print("No audio file found")
        }
    }

    
}


PlaygroundPage.current.setLiveView(ContentView())


//: [Next](@next)

//: [Previous](@previous)

import SwiftUI
import PlaygroundSupport
import AVFoundation

struct ContentView: View {
   @State var scale = 0.80
   @State var rotation = false
    @State var scena = true
    @State var scena1 = true
    @State var fine = false
    @State var cabinaX : CGFloat = 305
    @State var cabinaY : CGFloat = -200
    @State var cabinaScale = 0.30
    @State var manoX : CGFloat = 300
    @State var manoY : CGFloat = 500
    @State var manovisible = true
    @State var Flash: AVAudioPlayer?
    @State var crowd: AVAudioPlayer?
    @State var astonished: AVAudioPlayer?
    @State var Pulsante : AVAudioPlayer?
    @State var Urlo : AVAudioPlayer?
    
   var body: some View {
       if(scena1){
           VStack{
               
               HStack{
                   Button {
                       if(manovisible){
                           manoX = 300
                           manoY = 290
                           manovisible=false
                           startPulsante()
                       }
                       
                       else if(!manovisible){
                              scena1=false
                       }
                    } label: {
                        Image(uiImage: UIImage(named: "next.png")!).resizable().frame(width: 50, height: 50)
                            }
                    .offset(x: 270, y: 340)
               }
               Image(uiImage: UIImage(named: "MANO2.png")!)
                   .padding()
                   .scaledToFit()
                   .scaleEffect(0.55)
                   .transition(.move(edge: .top))
                   .animation(
                    .linear(duration: 1),
                       value: manoX)
                   .animation(
                    .linear(duration: 0.2),
                       value: manoY)
                   .position(x: manoX, y: manoY)
                               
               Text("''What a coincidence'', Gibbons exclaimed. ''1939 is my family’s phone number''. Then he pressed the green button to call.")
                                       .font(.system(size: 17, weight: .light, design: .serif))
                                       .frame(width: 520)
                                       .foregroundColor(.blue)
                                       .background(Color.yellow)
                                       .cornerRadius(10)
                                       .offset(x: -30 ,y: -8)
           }
           
           .frame(width: 600, height: 400)
               .background(Image(uiImage: UIImage(named: "scene3.jpeg")!).resizable().aspectRatio(contentMode: .fill))
           
       }
       
       
       if(!scena1 && scena){
       VStack {
           
           HStack {
               
               Image(uiImage: UIImage(named: "Comic2.png")!)
                   .resizable()
                   .scaledToFit()
                   .frame(width: 910, height: 910)
                   .padding()
                   .scaleEffect(scale)
                   .animation(
                       .linear(duration: 2),
                       value: scale
                   )
               
                   .onAppear {
                       startFlash()
                       rotation = true
                   }
                   .padding()
                   .rotationEffect(rotation ? .zero : Angle.degrees(360))
                   .animation(
                    .linear(duration: 0.5).repeatForever(autoreverses: false),
                       value: rotation
                   )
               
               
               
                   .offset(x: 19, y: 310)
               Spacer()
           }
           
           Spacer()
           Image(uiImage: UIImage(named: "FLASH.png")!)
               .resizable()
               .scaledToFit()
               .frame(width: 740, height: 500)
               .padding()
               
               .onTapGesture {
                   rotation = true
               }
               .padding()
               .rotationEffect(rotation ? .zero : Angle.degrees(0))
               .animation(
                   .linear(duration: 3).repeatForever(autoreverses: false),
                   value: rotation
               )
           
           .offset(x: 0, y: -465)
           
       }
       .frame(width: 600, height: 400)
           HStack{
           Text("Suddenly there was a great roar, a strong light and...")
                                   .font(.system(size: 19, weight: .light, design: .serif))
                                   .frame(width: 500)
                                   .foregroundColor(.blue)
                                   .background(Color.yellow)
                                   .cornerRadius(10)
                                   .offset(y: -25)
               Button {
                              scena=false
                              Flash?.stop()
                                   } label: {
                                       Image(uiImage: UIImage(named: "next.png")!).resizable().frame(width: 50, height: 50)
                                       }
                                   .offset(x: 10, y: -40)
           }
           }
       
       if(!scena){
           VStack{
               
               Image(uiImage: UIImage(named: "SCENA.001.jpeg")!)
                   .resizable()
                   .scaledToFit()
                   .frame(width: 1030, height: 830)
                   .padding()
                   .onAppear{
                       startCrowd()
                   }
               
               
               Image(uiImage: UIImage(named: "cabina.png")!)
                               .padding()
                               .scaledToFit()
                               .scaleEffect(cabinaScale)
                               .transition(.move(edge: .top))
                               .position(x: 305, y: -595)
                               .animation(
                                .linear(duration: 1.3),
                                   value: cabinaX)
                               .animation(
                                .linear(duration: 0.3),
                                   value: cabinaY)
                               .position(x: cabinaX, y: cabinaY)
               
               
               Text("...Gibbons finds himself in the sky in the cabin in free fall.")
                                       .font(.system(size: 18, weight: .light, design: .serif))
                                       .frame(width: 515)
                                       .foregroundColor(.blue)
                                       .background(Color.yellow)
                                       .cornerRadius(10)
                                       .offset(x: -30 , y: -226)
               
               
               
               Button {
                   if (!fine) {
                       cabinaX = 292
                       cabinaY = 165
                       crowd?.stop()
                       startUrlo()
                       DispatchQueue.main.asyncAfter(deadline: .now() + 1, execute: {
                              startAstonished()
                       })
                       fine = true
                   }
                   
                           } label: {
                               Image(uiImage: UIImage(named: "next.png")!).resizable().frame(width: 50, height: 50)
                             }
                           .offset(x: 265, y: -288)
            
               
               
           }
       }
       
       
   }
    
    func startFlash() {
               if let audioURL = Bundle.main.url(forResource: "flash", withExtension: "mp3") {
                   do {
                       try Flash = AVAudioPlayer(contentsOf: audioURL)
                       Flash?.numberOfLoops = 0
                       Flash?.play()
                       
                   } catch {
                       print("Couldn't play audio. Error: \(error)")
                   }
                   
               } else {
                   print("No audio file found")
               }
           }
    func startCrowd() {
               if let audioURL = Bundle.main.url(forResource: "crowd", withExtension: "wav") {
                   do {
                       try crowd = AVAudioPlayer(contentsOf: audioURL)
                       crowd?.numberOfLoops = 0
                       crowd?.play()
                    
                       
                   } catch {
                       print("Couldn't play audio. Error: \(error)")
                   }
                   
               } else {
                   print("No audio file found")
               }
           }
    func startAstonished() {
               if let audioURL = Bundle.main.url(forResource: "astonished", withExtension: "mp3") {
                   do {
                       try astonished = AVAudioPlayer(contentsOf: audioURL)
                       astonished?.numberOfLoops = 0
                       astonished?.play()
                       
                   } catch {
                       print("Couldn't play audio. Error: \(error)")
                   }
                   
               } else {
                   print("No audio file found")
               }
           }
    
    func startPulsante() {
               if let audioURL = Bundle.main.url(forResource: "bot", withExtension: "mp3") {
                   do {
                       try Pulsante = AVAudioPlayer(contentsOf: audioURL)
                       Pulsante?.numberOfLoops = 0
                       Pulsante?.play()
                       
                   } catch {
                       print("Couldn't play audio. Error: \(error)")
                   }
                   
               } else {
                   print("No audio file found")
               }
           }
    
    func startUrlo() {
               if let audioURL = Bundle.main.url(forResource: "Urlo", withExtension: "mp3") {
                   do {
                       try Urlo = AVAudioPlayer(contentsOf: audioURL)
                       Urlo?.numberOfLoops = 0
                       Urlo?.play()
                       
                   } catch {
                       print("Couldn't play audio. Error: \(error)")
                   }
                   
               } else {
                   print("No audio file found")
               }
           }
}

PlaygroundPage.current.setLiveView(ContentView())

//: [Next](@next)
